import { useState, useEffect, useRef } from "react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const TELESCOPES = [
  { name: "Tecnosky AG 90mm V2 APO", focalLength: 450, aperture: 90, note: "Apocromatico tripletto FPL-53, f/5 – ideale deep sky a campo medio e wide field" },
  { name: "Tecnosky 102mm OWL", focalLength: 714, aperture: 102, note: "Apocromatico tripletto f/7 serie OWL – versatile deep sky e planetario leggero" },
  { name: "Tecnosky 60mm FPL-53", focalLength: 360, aperture: 60, note: "Rifrattore apo f/6 compatto FPL-53 – campo largo e wide field" },
  { name: "RC Tecnosky 200/2400", focalLength: 2400, aperture: 200, note: "Ritchey-Chretien f/12 – deep sky ad alta risoluzione, galassie e nebulose planetarie" },
  { name: "Heliostar 100 H-alpha", focalLength: 700, aperture: 100, note: "Rifrattore dedicato solare H-alpha f/7 – ottimizzato per protuberanze e cromosfera" },
];

const CAMERAS = [
  // ── ZWO – Deep Sky raffreddate ──
  { name: "ZWO ASI6200MM Pro", pixelSize: 3.76, sensor: "FF 36×24mm", type: "mono", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI6200MC Pro", pixelSize: 3.76, sensor: "FF 36×24mm", type: "color", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI2600MM Pro", pixelSize: 3.76, sensor: "APS-C 23.5×15.7mm", type: "mono", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI2600MC Pro", pixelSize: 3.76, sensor: "APS-C 23.5×15.7mm", type: "color", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI2400MC Pro", pixelSize: 5.94, sensor: "FF 36×24mm", type: "color", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI294MM Pro", pixelSize: 4.63, sensor: "4/3\" 19.1×13mm", type: "mono", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI294MC Pro", pixelSize: 4.63, sensor: "4/3\" 19.1×13mm", type: "color", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI585MM Pro", pixelSize: 2.9, sensor: "1/1.2\" 11.2×6.3mm", type: "mono", cooling: true, brand: "ZWO", category: "Deep Sky" },
  { name: "ZWO ASI585MC Pro", pixelSize: 2.9, sensor: "1/1.2\" 11.2×6.3mm", type: "color", cooling: true, brand: "ZWO", category: "Deep Sky" },
  // ── ZWO – Planetario/Solare ──
  { name: "ZWO ASI678MC", pixelSize: 2.0, sensor: "1/2.8\" 7.7×4.3mm", type: "color", cooling: false, brand: "ZWO", category: "Planetario/Solare" },
  { name: "ZWO ASI662MC", pixelSize: 2.9, sensor: "1/2.8\" 5.6×3.2mm", type: "color", cooling: false, brand: "ZWO", category: "Planetario/Solare" },
  { name: "ZWO ASI664MC", pixelSize: 2.9, sensor: "1/1.8\" 7.8×4.4mm", type: "color", cooling: false, brand: "ZWO", category: "Planetario/Solare" },
  { name: "ZWO ASI432MM", pixelSize: 9.0, sensor: "1.1\" 14.5×9.9mm", type: "mono", cooling: false, brand: "ZWO", category: "Solare" },
  // ── Player One – Deep Sky raffreddate ──
  { name: "PL1 Zeus-455M Pro", pixelSize: 3.76, sensor: "FF 36×24mm", type: "mono", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Zeus-455C Pro", pixelSize: 3.76, sensor: "FF 36×24mm", type: "color", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Poseidon-M Pro", pixelSize: 3.76, sensor: "APS-C 23.5×15.7mm", type: "mono", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Poseidon-C Pro", pixelSize: 3.76, sensor: "APS-C 23.5×15.7mm", type: "color", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Artemis-M Pro", pixelSize: 2.4, sensor: "APS-C 11.3×7.1mm", type: "mono", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Artemis-C Pro", pixelSize: 4.63, sensor: "4/3\" 17.4×13mm", type: "color", cooling: true, brand: "Player One", category: "Deep Sky" },
  { name: "PL1 Ares-M Pro", pixelSize: 3.76, sensor: "1\" 13.1×13.1mm", type: "mono", cooling: true, brand: "Player One", category: "Deep Sky" },
  // ── Player One – Planetario ──
  { name: "PL1 Neptune-C II", pixelSize: 2.9, sensor: "1/2\" 7.4×5.6mm", type: "color", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Neptune-M II", pixelSize: 2.9, sensor: "1/2\" 7.4×5.6mm", type: "mono", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Uranus-C", pixelSize: 2.9, sensor: "1/1.2\" 12.5×7.1mm", type: "color", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Uranus-M", pixelSize: 2.9, sensor: "1/1.2\" 12.5×7.1mm", type: "mono", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Saturn-C SQR", pixelSize: 3.76, sensor: "1\" 13.1×13.1mm", type: "color", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Saturn-M SQR", pixelSize: 3.76, sensor: "1\" 13.1×13.1mm", type: "mono", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Mars-C (IMX462)", pixelSize: 2.9, sensor: "1/2.8\" 6.4×4.8mm", type: "color", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  { name: "PL1 Mars-M (IMX662)", pixelSize: 2.9, sensor: "1/2.8\" 5.6×3.2mm", type: "mono", cooling: false, brand: "Player One", category: "Planetario/Solare" },
  // ── Player One – Solare ──
  { name: "PL1 Apollo-M MAX (IMX432)", pixelSize: 9.0, sensor: "1.1\" 14.5×9.9mm", type: "mono", cooling: false, brand: "Player One", category: "Solare" },
  { name: "PL1 Apollo-428M MAX", pixelSize: 4.5, sensor: "1.1\" 14.5×9.9mm", type: "mono", cooling: false, brand: "Player One", category: "Solare" },
  { name: "PL1 Apollo-M MINI", pixelSize: 4.5, sensor: "2/3\" 8.8×6.6mm", type: "mono", cooling: false, brand: "Player One", category: "Solare" },
];

// Barlow disponibili (moltiplicatore focale)
const BARLOWS = [
  { name: "Nessuna Barlow", factor: 1 },
  { name: "Barlow 1.5×", factor: 1.5 },
  { name: "Barlow 2×", factor: 2 },
  { name: "Barlow 2.5×", factor: 2.5 },
  { name: "Barlow 3×", factor: 3 },
  { name: "Barlow 4×", factor: 4 },
  { name: "Barlow 5×", factor: 5 },
];

// Filtri ottici speciali
const SPECIAL_FILTERS = [
  { id: "none", name: "Nessun filtro", focalMultiplier: 1, desc: "", color: "rgba(180,200,230,0.3)" },
  {
    id: "quark_chrom",
    name: "Daystar Quark Cromosfera",
    focalMultiplier: 4.3,
    desc: "Filtro H-alpha 0.5Å per cromosfera solare. Moltiplica la focale effettiva ~4.3×. Richiede telescopio f/4–f/8. Usare solo con oggetto Solare.",
    color: "#ff6e40",
    solarOnly: true,
    wavelength: "H-alpha 656.3 nm",
    bandwidth: "< 0.5 Å",
  },
];

const OBJECT_TYPES = [
  {
    id: "deepsky_wide",
    label: "Deep Sky – Campo largo",
    icon: "🌌",
    description: "Nebulose estese, galassie grandi, ammassi aperti",
    idealSampling: { min: 1.5, max: 3.5 },
    focalRatio: { min: 4, max: 7 },
    notes: "Preferire camere a sensore grande (APS-C o FF). Riduttori focali consigliati su SC/RC.",
    color: "#4fc3f7",
  },
  {
    id: "deepsky_narrow",
    label: "Deep Sky – Alto ingrandimento",
    icon: "🔭",
    description: "Galassie piccole, nebulose planetarie, ammassi globulari",
    idealSampling: { min: 0.5, max: 1.5 },
    focalRatio: { min: 7, max: 12 },
    notes: "Campionamento fine. Occorre seeing eccellente e montatura precisa.",
    color: "#b39ddb",
  },
  {
    id: "lunar_planetary",
    label: "Lunare / Planetario",
    icon: "🪐",
    description: "Luna, Giove, Saturno, Marte, Venere",
    idealSampling: { min: 0.1, max: 0.4 },
    focalRatio: { min: 15, max: 40 },
    notes: "Pixel piccoli (<3µm) e frame rate elevato. Lucky imaging con barlow 2-5x.",
    color: "#ffcc80",
  },
  {
    id: "solar",
    label: "Solare",
    icon: "☀️",
    description: "Sole in luce bianca, H-alpha, Ca-K",
    idealSampling: { min: 0.1, max: 0.5 },
    focalRatio: { min: 20, max: 50 },
    notes: "Filtro solare obbligatorio. Camere monocromatiche per H-alpha/Ca-K.",
    color: "#ff8a65",
  },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function calcSampling(pixelSizeMicron, focalLengthMm) {
  return (206.265 * pixelSizeMicron) / focalLengthMm;
}

function focalRatioLabel(ratio) {
  if (ratio < 5) return { label: "Molto rapido", color: "#81c784" };
  if (ratio < 8) return { label: "Rapido", color: "#aed581" };
  if (ratio < 12) return { label: "Medio", color: "#fff176" };
  if (ratio < 20) return { label: "Lento", color: "#ffb74d" };
  return { label: "Molto lento", color: "#e57373" };
}

function samplingRating(sampling, objectType) {
  const { min, max } = objectType.idealSampling;
  if (sampling >= min && sampling <= max) return { label: "Ottimale ✓", color: "#81c784", score: 3 };
  const margin = (max - min) * 0.5;
  if (sampling >= min - margin && sampling <= max + margin) return { label: "Accettabile ~", color: "#fff176", score: 2 };
  if (sampling < min) return { label: "Sotto-campionato ↓", color: "#ffb74d", score: 1 };
  return { label: "Sovra-campionato ↑", color: "#ef9a9a", score: 1 };
}

// ─── MOTORE DI RACCOMANDAZIONE CAMERA ────────────────────────────────────────

function recommendCameras(telescope, objectType, barlow, filter) {
  const barlowF = barlow?.factor || 1;
  const filterF = filter?.focalMultiplier || 1;
  const focalLength = telescope.focalLength * barlowF * filterF;
  if (!focalLength) return [];

  const { min: sMin, max: sMax } = objectType.idealSampling;

  // pixel ideale target: centro del range ideale di campionamento
  const targetSampling = (sMin + sMax) / 2;
  const targetPixel = (targetSampling * focalLength) / 206.265;

  // calcola score per ogni camera
  const scored = CAMERAS.map(cam => {
    const sampling = calcSampling(cam.pixelSize, focalLength);
    const { score } = samplingRating(sampling, objectType);
    const pixelDist = Math.abs(cam.pixelSize - targetPixel);
    const sampingStr = sampling.toFixed(2);

    // bonus/malus categorie
    let bonus = 0;
    if (objectType.id === "solar" || objectType.id === "lunar_planetary") {
      if (cam.category === "Planetario/Solare" || cam.category === "Solare") bonus += 2;
      if (cam.cooling) bonus -= 0.5; // cooling non necessario per planetario
    }
    if (objectType.id === "deepsky_wide" || objectType.id === "deepsky_narrow") {
      if (cam.category === "Deep Sky") bonus += 2;
      if (cam.cooling) bonus += 1;
      if (cam.type === "mono") bonus += 0.5;
    }
    if (objectType.id === "solar") {
      if (cam.type === "mono") bonus += 1;
      if (cam.category === "Solare") bonus += 1;
    }

    const totalScore = score * 3 + bonus - pixelDist * 0.4;
    return { cam, sampling: parseFloat(sampingStr), score: totalScore, pixelDist };
  });

  // ordina e prendi top 3
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3).map(s => ({ ...s.cam, computedSampling: s.sampling }));
}

function samplingRatingSimple(sampling, objectType) {
  return samplingRating(sampling, objectType);
}

function StarField() {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight;
    const stars = Array.from({ length: 180 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.2 + 0.2,
      a: Math.random(),
      speed: Math.random() * 0.008 + 0.002,
    }));
    let raf;
    function draw() {
      ctx.clearRect(0, 0, W, H);
      stars.forEach(s => {
        s.a += s.speed;
        const alpha = (Math.sin(s.a) + 1) / 2 * 0.8 + 0.1;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(200,220,255,${alpha})`;
        ctx.fill();
      });
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }} />;
}

function GaugeArc({ value, min, max, color, label }) {
  const pct = Math.min(1, Math.max(0, (value - min) / (max - min)));
  const angle = pct * 180;
  const r = 54;
  const cx = 70, cy = 70;
  const startAngle = Math.PI;
  const endAngle = startAngle + (angle / 180) * Math.PI;
  const x1 = cx + r * Math.cos(startAngle);
  const y1 = cy + r * Math.sin(startAngle);
  const x2 = cx + r * Math.cos(endAngle);
  const y2 = cy + r * Math.sin(endAngle);
  const large = angle > 180 ? 1 : 0;
  return (
    <svg width="140" height="80" style={{ overflow: "visible" }}>
      <path d={`M${cx - r},${cy} A${r},${r} 0 0 1 ${cx + r},${cy}`} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="8" strokeLinecap="round" />
      {pct > 0 && (
        <path d={`M${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2}`} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round" style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
      )}
      <text x={cx} y={cy - 6} textAnchor="middle" fill="white" fontSize="15" fontFamily="'Space Mono', monospace" fontWeight="bold">{label}</text>
    </svg>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  // telescope
  const [teleMode, setTeleMode] = useState("preset"); // preset | custom
  const [selectedTele, setSelectedTele] = useState(TELESCOPES[0]);
  const [customTeleName, setCustomTeleName] = useState("");
  const [customFocal, setCustomFocal] = useState("");
  const [customAperture, setCustomAperture] = useState("");

  // camera
  const [camMode, setCamMode] = useState("preset");
  const [selectedCam, setSelectedCam] = useState(CAMERAS[0]);
  const [customCamName, setCustomCamName] = useState("");
  const [customPixel, setCustomPixel] = useState("");

  // object type
  const [objectType, setObjectType] = useState(OBJECT_TYPES[0]);

  // binning
  const [binning, setBinning] = useState(1);

  // barlow
  const [selectedBarlow, setSelectedBarlow] = useState(BARLOWS[0]);

  // special filter
  const [selectedFilter, setSelectedFilter] = useState(SPECIAL_FILTERS[0]);

  // computed
  const telescope = teleMode === "preset"
    ? selectedTele
    : { name: customTeleName || "Telescopio Custom", focalLength: parseFloat(customFocal) || 0, aperture: parseFloat(customAperture) || 0 };

  const camera = camMode === "preset"
    ? selectedCam
    : { name: customCamName || "Camera Custom", pixelSize: parseFloat(customPixel) || 0 };

  const effectivePixel = camera.pixelSize * binning;
  const baseFocalLength = telescope.focalLength;
  const aperture = telescope.aperture;
  // Focale effettiva = focale base × barlow × filtro
  const barlowFactor = selectedBarlow.factor;
  const filterFocalFactor = selectedFilter.focalMultiplier;
  const focalLength = baseFocalLength * barlowFactor * filterFocalFactor;
  const fRatio = aperture > 0 ? focalLength / aperture : 0;
  const sampling = focalLength > 0 ? calcSampling(effectivePixel, focalLength) : 0;
  const sampRating = samplingRating(sampling, objectType);
  const frInfo = focalRatioLabel(fRatio);

  // warning filtro solare su oggetto non-solare
  const filterSolarWarning = selectedFilter.solarOnly && objectType.id !== "solar";

  const isValid = focalLength > 0 && effectivePixel > 0;

  return (
    <div style={{
      minHeight: "100vh",
      background: "radial-gradient(ellipse at 20% 30%, #0a1628 0%, #040810 50%, #000408 100%)",
      fontFamily: "'Space Mono', 'Courier New', monospace",
      color: "#c8d8f0",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Nebula background blobs */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", top: "5%", left: "10%", width: 400, height: 300, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(60,30,120,0.18) 0%, transparent 70%)", filter: "blur(40px)" }} />
        <div style={{ position: "absolute", top: "40%", right: "5%", width: 350, height: 250, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(20,80,140,0.14) 0%, transparent 70%)", filter: "blur(50px)" }} />
        <div style={{ position: "absolute", bottom: "10%", left: "30%", width: 500, height: 200, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(100,40,20,0.10) 0%, transparent 70%)", filter: "blur(60px)" }} />
        <StarField />
      </div>

      <div style={{ position: "relative", zIndex: 1, maxWidth: 960, margin: "0 auto", padding: "32px 16px 64px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{ fontSize: 11, letterSpacing: "0.35em", color: "#ff8a65", marginBottom: 8, textTransform: "uppercase" }}>
            ✦ Solarmax Home Observatory ✦
          </div>
          <h1 style={{ fontSize: "clamp(1.8rem, 5.5vw, 3rem)", fontWeight: 700, margin: 0, letterSpacing: "-0.02em", lineHeight: 1.1, background: "linear-gradient(135deg, #ffe0b2 0%, #ff8a65 40%, #4fc3f7 80%, #b39ddb 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            AstroSampling
          </h1>
          <p style={{ marginTop: 10, color: "rgba(180,200,230,0.5)", fontSize: 12, letterSpacing: "0.12em" }}>
            Telescopio · Camera · Oggetto → Campionamento ideale
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 20, marginBottom: 24 }}>

          {/* ── STEP 1: OGGETTO ── */}
          <Card title="① Tipo di oggetto" accent="#ff8a65">
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {OBJECT_TYPES.map(ot => (
                <button key={ot.id} onClick={() => setObjectType(ot)} style={{
                  textAlign: "left", padding: "10px 14px", borderRadius: 8,
                  border: objectType.id === ot.id ? `1px solid ${ot.color}` : "1px solid rgba(255,255,255,0.06)",
                  background: objectType.id === ot.id ? `rgba(${hexToRgb(ot.color)},0.12)` : "rgba(255,255,255,0.03)",
                  cursor: "pointer", transition: "all 0.15s", fontFamily: "inherit",
                  boxShadow: objectType.id === ot.id ? `0 0 14px rgba(${hexToRgb(ot.color)},0.25)` : "none",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                    <span style={{ fontSize: 16 }}>{ot.icon}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: objectType.id === ot.id ? ot.color : "#c8d8f0", letterSpacing: "0.04em" }}>{ot.label}</span>
                  </div>
                  <div style={{ fontSize: 11, color: "rgba(180,200,230,0.45)", paddingLeft: 24 }}>{ot.description}</div>
                  {objectType.id === ot.id && (
                    <div style={{ paddingLeft: 24, marginTop: 4, fontSize: 10, color: ot.color }}>
                      Campionamento ideale: {ot.idealSampling.min}"–{ot.idealSampling.max}"/px · f/{ot.focalRatio.min}–f/{ot.focalRatio.max}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </Card>

          {/* ── STEP 2: TELESCOPIO ── */}
          <Card title="② Telescopio" accent="#4fc3f7">
            <TabToggle value={teleMode} onChange={setTeleMode} options={[{ value: "preset", label: "Predefinito" }, { value: "custom", label: "Personalizzato" }]} accent="#4fc3f7" />
            {teleMode === "preset" ? (
              <>
                <Select value={selectedTele.name} onChange={v => setSelectedTele(TELESCOPES.find(t => t.name === v))} accent="#4fc3f7">
                  {TELESCOPES.map(t => <option key={t.name} value={t.name}>{t.name}</option>)}
                </Select>
                {selectedTele.note && (
                  <div style={{ fontSize: 10, color: "rgba(79,195,247,0.55)", lineHeight: 1.6, marginBottom: 8, fontStyle: "italic" }}>
                    {selectedTele.note}
                  </div>
                )}
              </>
            ) : (
              <>
                <Input label="Nome modello" value={customTeleName} onChange={setCustomTeleName} placeholder="es. Mio Rifrattore 80mm" />
                <Input label="Lunghezza focale (mm)" value={customFocal} onChange={setCustomFocal} placeholder="es. 600" type="number" />
                <Input label="Apertura (mm)" value={customAperture} onChange={setCustomAperture} placeholder="es. 80" type="number" />
              </>
            )}
            <InfoRow label="Focale base" value={baseFocalLength > 0 ? `${baseFocalLength} mm` : "—"} />
            <InfoRow label="Apertura" value={aperture > 0 ? `${aperture} mm` : "—"} />
            {(barlowFactor > 1 || filterFocalFactor > 1) && baseFocalLength > 0 && (
              <InfoRow label="Focale effettiva" value={`${focalLength.toFixed(0)} mm`} color="#4fc3f7" />
            )}
            {fRatio > 0 && (
              <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 12, color: "rgba(180,200,230,0.6)" }}>Rapporto f/</span>
                <span style={{ fontWeight: 700, color: frInfo.color, fontSize: 15, textShadow: `0 0 10px ${frInfo.color}` }}>f/{fRatio.toFixed(1)}</span>
                <span style={{ fontSize: 11, color: frInfo.color, marginLeft: 4 }}>{frInfo.label}</span>
              </div>
            )}
          </Card>

          {/* ── STEP 4: CAMERA (conferma o modifica) ── */}
          <Card title="④ Camera – Conferma o modifica" accent="#b39ddb">
            <TabToggle value={camMode} onChange={setCamMode} options={[{ value: "preset", label: "Predefinita" }, { value: "custom", label: "Personalizzata" }]} accent="#b39ddb" />
            {camMode === "preset" ? (
              <>
                <Select value={selectedCam.name} onChange={v => setSelectedCam(CAMERAS.find(c => c.name === v))} accent="#b39ddb">
                  {["Deep Sky", "Planetario/Solare", "Solare"].map(cat => {
                    const grouped = CAMERAS.filter(c => c.category === cat);
                    const zwoCams = grouped.filter(c => c.brand === "ZWO");
                    const plCams = grouped.filter(c => c.brand === "Player One");
                    return [
                      zwoCams.length > 0 && <optgroup key={`zwo-${cat}`} label={`── ZWO · ${cat}`}>{zwoCams.map(c => <option key={c.name} value={c.name}>{c.name} · {c.pixelSize}µm · {c.sensor} {c.cooling ? "❄" : ""}</option>)}</optgroup>,
                      plCams.length > 0 && <optgroup key={`pl-${cat}`} label={`── Player One · ${cat}`}>{plCams.map(c => <option key={c.name} value={c.name}>{c.name} · {c.pixelSize}µm · {c.sensor} {c.cooling ? "❄" : ""}</option>)}</optgroup>,
                    ];
                  })}
                </Select>
                <div style={{ display: "flex", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
                  <Tag color={selectedCam.type === "mono" ? "#b39ddb" : "#ffb74d"}>{selectedCam.type === "mono" ? "⬛ Monocromatica" : "🌈 Colore"}</Tag>
                  {selectedCam.cooling && <Tag color="#4fc3f7">❄ Raffreddata</Tag>}
                  <Tag color="rgba(180,200,230,0.5)">{selectedCam.category}</Tag>
                </div>
              </>
            ) : (
              <>
                <Input label="Nome modello" value={customCamName} onChange={setCustomCamName} placeholder="es. La mia ASI personalizzata" />
                <Input label="Dimensione pixel (µm)" value={customPixel} onChange={setCustomPixel} placeholder="es. 3.76" type="number" />
              </>
            )}
            <InfoRow label="Pixel fisico" value={camera.pixelSize > 0 ? `${camera.pixelSize} µm` : "—"} />
            {camMode === "preset" && selectedCam.sensor && <InfoRow label="Sensore" value={selectedCam.sensor} />}
            {/* Binning */}
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 11, color: "rgba(180,200,230,0.55)", marginBottom: 6, letterSpacing: "0.08em" }}>BINNING</div>
              <div style={{ display: "flex", gap: 8 }}>
                {[1, 2, 3, 4].map(b => (
                  <button key={b} onClick={() => setBinning(b)} style={{
                    flex: 1, padding: "6px 0", borderRadius: 6, border: binning === b ? `1px solid #b39ddb` : "1px solid rgba(255,255,255,0.08)",
                    background: binning === b ? "rgba(179,157,219,0.18)" : "rgba(255,255,255,0.04)",
                    color: binning === b ? "#b39ddb" : "rgba(180,200,230,0.5)", cursor: "pointer", fontSize: 13,
                    fontFamily: "inherit", fontWeight: binning === b ? 700 : 400, transition: "all 0.15s",
                    boxShadow: binning === b ? `0 0 10px rgba(179,157,219,0.3)` : "none",
                  }}>{b}×{b}</button>
                ))}
              </div>
            </div>
            {binning > 1 && <InfoRow label="Pixel effettivo" value={`${effectivePixel.toFixed(2)} µm`} color="#b39ddb" />}
          </Card>

          {/* ── STEP 3: ACCESSORI ── */}
          <Card title="③ Accessori ottici" accent="#a5d6a7">
            {/* Barlow */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, letterSpacing: "0.15em", color: "rgba(165,214,167,0.7)", marginBottom: 8, fontWeight: 700 }}>BARLOW / AMPLIFICATORE FOCALE</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                {BARLOWS.map(b => (
                  <button key={b.factor} onClick={() => setSelectedBarlow(b)} style={{
                    textAlign: "left", padding: "7px 12px", borderRadius: 7,
                    border: selectedBarlow.factor === b.factor ? "1px solid rgba(165,214,167,0.6)" : "1px solid rgba(255,255,255,0.06)",
                    background: selectedBarlow.factor === b.factor ? "rgba(165,214,167,0.12)" : "rgba(255,255,255,0.03)",
                    color: selectedBarlow.factor === b.factor ? "#a5d6a7" : "rgba(180,200,230,0.5)",
                    cursor: "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: selectedBarlow.factor === b.factor ? 700 : 400,
                    transition: "all 0.15s",
                    boxShadow: selectedBarlow.factor === b.factor ? "0 0 8px rgba(165,214,167,0.2)" : "none",
                  }}>
                    {b.factor === 1 ? "✕ " : `${b.factor}× `}{b.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Filtri speciali */}
            <div>
              <div style={{ fontSize: 10, letterSpacing: "0.15em", color: "rgba(255,110,64,0.7)", marginBottom: 8, fontWeight: 700 }}>FILTRO SPECIALE</div>
              {SPECIAL_FILTERS.map(f => (
                <button key={f.id} onClick={() => setSelectedFilter(f)} style={{
                  width: "100%", textAlign: "left", padding: "10px 12px", borderRadius: 8, marginBottom: 6,
                  border: selectedFilter.id === f.id ? `1px solid ${f.color}` : "1px solid rgba(255,255,255,0.06)",
                  background: selectedFilter.id === f.id ? `rgba(${hexToRgb(f.color)},0.12)` : "rgba(255,255,255,0.03)",
                  cursor: "pointer", fontFamily: "inherit", transition: "all 0.15s",
                  boxShadow: selectedFilter.id === f.id ? `0 0 10px rgba(${hexToRgb(f.color)},0.25)` : "none",
                }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: selectedFilter.id === f.id ? f.color : "rgba(180,200,230,0.55)", marginBottom: f.desc ? 4 : 0 }}>
                    {f.id === "none" ? "◎ " : "🌞 "}{f.name}
                  </div>
                  {f.desc && selectedFilter.id === f.id && (
                    <div style={{ fontSize: 10, color: "rgba(255,110,64,0.65)", lineHeight: 1.5, marginTop: 4 }}>
                      {f.wavelength && <span style={{ display: "block" }}>λ {f.wavelength} · bw {f.bandwidth}</span>}
                      <span style={{ display: "block", marginTop: 2 }}>{f.desc}</span>
                    </div>
                  )}
                </button>
              ))}
              {filterSolarWarning && (
                <div style={{ fontSize: 10, color: "#ff6e40", background: "rgba(255,110,64,0.1)", borderRadius: 6, padding: "6px 10px", marginTop: 4, lineHeight: 1.5 }}>
                  ⚠️ Il Daystar Quark è un filtro solare. Seleziona il tipo oggetto "Solare" per risultati corretti.
                </div>
              )}
            </div>
          </Card>
          <Card title="🌠 Tipo di oggetto" accent="#ff8a65">
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {OBJECT_TYPES.map(ot => (
                <button key={ot.id} onClick={() => setObjectType(ot)} style={{
                  textAlign: "left", padding: "10px 14px", borderRadius: 8,
                  border: objectType.id === ot.id ? `1px solid ${ot.color}` : "1px solid rgba(255,255,255,0.06)",
                  background: objectType.id === ot.id ? `rgba(${hexToRgb(ot.color)},0.12)` : "rgba(255,255,255,0.03)",
                  cursor: "pointer", transition: "all 0.15s", fontFamily: "inherit",
                  boxShadow: objectType.id === ot.id ? `0 0 14px rgba(${hexToRgb(ot.color)},0.25)` : "none",
                }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                    <span style={{ fontSize: 16 }}>{ot.icon}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: objectType.id === ot.id ? ot.color : "#c8d8f0", letterSpacing: "0.04em" }}>{ot.label}</span>
                  </div>
                  <div style={{ fontSize: 11, color: "rgba(180,200,230,0.45)", paddingLeft: 24 }}>{ot.description}</div>
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* ── PANNELLO SUGGERIMENTO CAMERA ── */}
        {baseFocalLength > 0 && (() => {
          const recs = recommendCameras(telescope, objectType, selectedBarlow, selectedFilter);
          return (
            <div style={{
              marginBottom: 24,
              background: "linear-gradient(135deg, rgba(10,22,40,0.97) 0%, rgba(4,8,16,0.99) 100%)",
              border: `1px solid rgba(${hexToRgb(objectType.color)},0.35)`,
              borderRadius: 14, padding: "22px 24px",
              boxShadow: `0 0 30px rgba(${hexToRgb(objectType.color)},0.08)`,
              animation: "fadeIn 0.3s ease",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.2em", color: objectType.color, textTransform: "uppercase" }}>
                  🎯 Camere Consigliate per {objectType.icon} {objectType.label}
                </div>
              </div>
              <div style={{ fontSize: 11, color: "rgba(180,200,230,0.45)", marginBottom: 14, lineHeight: 1.6 }}>
                Con <strong style={{ color: "#4fc3f7" }}>{telescope.name}</strong> (focale eff. {focalLength.toFixed(0)}mm),
                il campionamento ideale è <strong style={{ color: objectType.color }}>{objectType.idealSampling.min}"–{objectType.idealSampling.max}"/px</strong>.
                Le camere sotto sono ordinate per compatibilità ottimale.
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 }}>
                {recs.map((cam, i) => {
                  const rating = samplingRatingSimple(cam.computedSampling, objectType);
                  const isSelected = camMode === "preset" && selectedCam.name === cam.name;
                  return (
                    <button key={cam.name} onClick={() => { setCamMode("preset"); setSelectedCam(CAMERAS.find(c => c.name === cam.name)); }}
                      style={{
                        textAlign: "left", padding: "14px 16px", borderRadius: 10, cursor: "pointer",
                        fontFamily: "inherit", transition: "all 0.18s",
                        border: isSelected ? `2px solid ${rating.color}` : `1px solid rgba(${hexToRgb(rating.color)},0.3)`,
                        background: isSelected ? `rgba(${hexToRgb(rating.color)},0.14)` : `rgba(${hexToRgb(rating.color)},0.05)`,
                        boxShadow: isSelected ? `0 0 18px rgba(${hexToRgb(rating.color)},0.3)` : "none",
                      }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
                        <span style={{ fontSize: 13, color: rating.color, fontWeight: 700 }}>
                          {i === 0 ? "🥇" : i === 1 ? "🥈" : "🥉"}
                        </span>
                        <span style={{ fontSize: 11, fontWeight: 700, color: isSelected ? rating.color : "#c8d8f0" }}>{cam.name}</span>
                      </div>
                      <div style={{ fontSize: 10, color: "rgba(180,200,230,0.5)", marginBottom: 6 }}>
                        {cam.sensor} · {cam.pixelSize}µm · {cam.type === "mono" ? "⬛ Mono" : "🌈 Colore"}{cam.cooling ? " · ❄" : ""}
                      </div>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <span style={{ fontSize: 11, color: rating.color, fontWeight: 700 }}>{cam.computedSampling}" /px</span>
                        <span style={{ fontSize: 10, color: rating.color, background: `rgba(${hexToRgb(rating.color)},0.12)`, padding: "2px 7px", borderRadius: 4 }}>{rating.label}</span>
                      </div>
                      {isSelected && <div style={{ marginTop: 6, fontSize: 9, color: rating.color, letterSpacing: "0.1em" }}>✓ SELEZIONATA</div>}
                    </button>
                  );
                })}
              </div>
              <div style={{ marginTop: 12, fontSize: 10, color: "rgba(180,200,230,0.3)", fontStyle: "italic" }}>
                💡 Clicca su una camera per selezionarla automaticamente, oppure modifica manualmente nella card Camera qui sotto.
              </div>
            </div>
          );
        })()}
        {isValid && (
          <div style={{ animation: "fadeIn 0.4s ease" }}>
            {(() => {
              const recs = recommendCameras(telescope, objectType, selectedBarlow, selectedFilter);
              const topRec = recs[0] || null;
              const isUsingRec = topRec && camMode === "preset" && camera.name === topRec.name;
              return (
                <ResultPanel
                  sampling={sampling}
                  objectType={objectType}
                  sampRating={sampRating}
                  fRatio={fRatio}
                  frInfo={frInfo}
                  telescope={telescope}
                  camera={camera}
                  effectivePixel={effectivePixel}
                  binning={binning}
                  barlow={selectedBarlow}
                  filter={selectedFilter}
                  baseFocalLength={baseFocalLength}
                  focalLength={focalLength}
                  topRec={topRec}
                  isUsingRec={isUsingRec}
                  camMode={camMode}
                />
              );
            })()}
          </div>
        )}

        {!isValid && (
          <div style={{ textAlign: "center", padding: "40px 20px", color: "rgba(180,200,230,0.3)", fontSize: 13, letterSpacing: "0.1em" }}>
            ↑ Inserisci telescopio e camera per calcolare il campionamento
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap');
        @keyframes fadeIn { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: rgba(79,195,247,0.3); border-radius: 2px; }
        select option { background: #0a1628; color: #c8d8f0; }
      `}</style>
    </div>
  );
}

// ─── HELPERS per rapporto focale ─────────────────────────────────────────────

function focalRatioRating(fRatio, objectType) {
  const { min, max } = objectType.focalRatio;
  if (fRatio >= min && fRatio <= max) return { label: "Ideale ✓", color: "#81c784", status: "ok" };
  const margin = (max - min) * 0.4;
  if (fRatio >= min - margin && fRatio <= max + margin) return { label: "Accettabile ~", color: "#fff176", status: "warn" };
  if (fRatio < min) return { label: "Troppo rapido ↑", color: "#ef9a9a", status: "fast" };
  return { label: "Troppo lento ↓", color: "#ffb74d", status: "slow" };
}

function fRatioAdvice(status, objectType) {
  const { min, max } = objectType.focalRatio;
  if (status === "ok") return null;
  if (status === "fast") return `⚠️ Il rapporto focale è troppo rapido per ${objectType.label}. Considera un amplificatore focale (Barlow) per raggiungere f/${min}–f/${max}.`;
  if (status === "slow") return `⚠️ Il rapporto focale è troppo lento per ${objectType.label}. Un riduttore focale ti porterà verso il range ideale f/${min}–f/${max}.`;
  return `~ Rapporto focale accettabile ma non ottimale. Il range ideale per ${objectType.label} è f/${min}–f/${max}.`;
}

// Barra lineare con zona evidenziata
function FocalRatioBar({ fRatio, idealMin, idealMax }) {
  const SCALE_MAX = 60;
  const toP = v => Math.min(100, (v / SCALE_MAX) * 100);
  const idealLeft = toP(idealMin);
  const idealWidth = toP(idealMax) - toP(idealMin);
  const markerPos = toP(fRatio);
  const rating = fRatio >= idealMin && fRatio <= idealMax ? "#81c784"
    : fRatio < idealMin - (idealMax - idealMin) * 0.4 || fRatio > idealMax + (idealMax - idealMin) * 0.4
      ? (fRatio < idealMin ? "#ef9a9a" : "#ffb74d") : "#fff176";

  // tick marks
  const ticks = [0, 4, 6, 8, 10, 15, 20, 30, 40, 50, 60];

  return (
    <div style={{ width: "100%", userSelect: "none" }}>
      {/* scale */}
      <div style={{ position: "relative", height: 32, marginBottom: 4 }}>
        {/* track */}
        <div style={{ position: "absolute", top: 14, left: 0, right: 0, height: 6, borderRadius: 3, background: "rgba(255,255,255,0.07)" }} />
        {/* ideal zone */}
        <div style={{
          position: "absolute", top: 14, left: `${idealLeft}%`, width: `${idealWidth}%`, height: 6,
          background: "rgba(129,199,132,0.35)", borderRadius: 2,
          boxShadow: "0 0 8px rgba(129,199,132,0.4)",
        }} />
        {/* ideal zone borders */}
        <div style={{ position: "absolute", top: 8, left: `${idealLeft}%`, width: 1, height: 18, background: "rgba(129,199,132,0.7)" }} />
        <div style={{ position: "absolute", top: 8, left: `${toP(idealMax)}%`, width: 1, height: 18, background: "rgba(129,199,132,0.7)" }} />
        {/* labels ideale */}
        <div style={{ position: "absolute", top: 0, left: `${idealLeft}%`, fontSize: 9, color: "rgba(129,199,132,0.8)", transform: "translateX(-50%)", letterSpacing: "0.05em" }}>f/{idealMin}</div>
        <div style={{ position: "absolute", top: 0, left: `${toP(idealMax)}%`, fontSize: 9, color: "rgba(129,199,132,0.8)", transform: "translateX(-50%)", letterSpacing: "0.05em" }}>f/{idealMax}</div>
        {/* marker */}
        {fRatio > 0 && (
          <div style={{
            position: "absolute", top: 10, left: `${markerPos}%`,
            transform: "translateX(-50%)",
            width: 12, height: 12, borderRadius: "50%",
            background: rating, boxShadow: `0 0 10px ${rating}, 0 0 20px ${rating}55`,
            border: "2px solid rgba(255,255,255,0.8)",
            transition: "left 0.3s ease",
            zIndex: 2,
          }} />
        )}
      </div>
      {/* tick marks */}
      <div style={{ position: "relative", height: 16 }}>
        {ticks.map(t => (
          <div key={t} style={{ position: "absolute", left: `${toP(t)}%`, transform: "translateX(-50%)", fontSize: 8, color: "rgba(180,200,230,0.3)", letterSpacing: "0.05em" }}>{t}</div>
        ))}
      </div>
      <div style={{ textAlign: "center", fontSize: 9, color: "rgba(180,200,230,0.3)", marginTop: 2, letterSpacing: "0.12em" }}>SCALA f/ (0 → 60)</div>
    </div>
  );
}

// Barra campionamento con zona ideale evidenziata
function SamplingBar({ sampling, min, max, color }) {
  const SCALE = max * 3;
  const toP = v => Math.min(100, (v / SCALE) * 100);
  const idealLeft = toP(min);
  const idealWidth = toP(max) - toP(min);
  const markerPos = Math.min(99, toP(sampling));
  return (
    <div style={{ position: "relative", height: 10 }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: 5, background: "rgba(255,255,255,0.07)" }} />
      <div style={{ position: "absolute", top: 0, bottom: 0, left: `${idealLeft}%`, width: `${idealWidth}%`, background: "rgba(129,199,132,0.25)", borderRadius: 3 }} />
      <div style={{
        position: "absolute", top: "50%", left: `${markerPos}%`,
        transform: "translate(-50%,-50%)",
        width: 10, height: 10, borderRadius: "50%",
        background: color, boxShadow: `0 0 6px ${color}`,
        border: "1.5px solid rgba(255,255,255,0.7)",
        transition: "left 0.3s ease",
      }} />
    </div>
  );
}

// ─── RESULT PANEL ─────────────────────────────────────────────────────────────

function ResultPanel({ sampling, objectType, sampRating, fRatio, frInfo, telescope, camera, effectivePixel, binning, barlow, filter, baseFocalLength, focalLength, topRec, isUsingRec, camMode }) {
  const { min, max } = objectType.idealSampling;
  const { min: frMin, max: frMax } = objectType.focalRatio;
  const sampDiff = sampling < min ? "sotto" : sampling > max ? "sopra" : "dentro";
  const frRating = fRatio > 0 ? focalRatioRating(fRatio, objectType) : null;
  const frAdvice = frRating ? fRatioAdvice(frRating.status, objectType) : null;

  // Confronto con camera consigliata
  const recSampling = topRec ? calcSampling(topRec.pixelSize, focalLength) : null;
  const recRating = recSampling ? samplingRating(recSampling, objectType) : null;
  const showComparison = topRec && !isUsingRec && camMode !== "custom";

  // differenza campionamento in %
  const sampDiffPct = recSampling ? ((sampling - recSampling) / recSampling * 100) : 0;
  const sampDiffDir = sampDiffPct > 5 ? "sovra" : sampDiffPct < -5 ? "sotto" : "ok";

  // messaggio confronto
  function comparisonMessage() {
    if (sampDiffDir === "ok") return { text: `Il campionamento della tua camera (${sampling.toFixed(2)}") è molto simile alla consigliata (${recSampling.toFixed(2)}"). Stai facendo una scelta equivalente.`, color: "#81c784", icon: "✅" };
    if (sampDiffDir === "sovra") return { text: `Con ${camera.name} stai sovracampionando del ${Math.abs(sampDiffPct).toFixed(0)}% rispetto alla ${topRec.name} (${sampling.toFixed(2)}" vs ${recSampling.toFixed(2)}"). Hai pixel più grandi del necessario: perdi risoluzione angolare ma guadagni SNR per oggetto.`, color: "#ffb74d", icon: "⚠️" };
    return { text: `Con ${camera.name} stai sottocampionando del ${Math.abs(sampDiffPct).toFixed(0)}% rispetto alla ${topRec.name} (${sampling.toFixed(2)}" vs ${recSampling.toFixed(2)}"). Hai pixel più piccoli del necessario: il seeing limiterà il dettaglio reale e aumenta il rumore di lettura.`, color: "#ef9a9a", icon: "⚠️" };
  }

  const cmpMsg = showComparison ? comparisonMessage() : null;

  return (
    <div style={{
      background: "linear-gradient(135deg, rgba(10,22,40,0.95) 0%, rgba(4,8,16,0.98) 100%)",
      border: `1px solid rgba(${hexToRgb(objectType.color)},0.3)`,
      borderRadius: 16, padding: "32px 28px",
      boxShadow: `0 0 40px rgba(${hexToRgb(objectType.color)},0.1), 0 20px 60px rgba(0,0,0,0.5)`,
    }}>

      {/* ── Titolo ── */}
      <div style={{ textAlign: "center", marginBottom: 28 }}>
        <div style={{ fontSize: 11, letterSpacing: "0.3em", color: "rgba(180,200,230,0.45)", marginBottom: 6, textTransform: "uppercase" }}>Risultati analisi ottica</div>
        <div style={{ fontSize: 13, color: objectType.color }}>{objectType.icon} {objectType.label}</div>
      </div>

      {/* ── Pannello doppio: campionamento + f/ ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>

        {/* Campionamento */}
        <div style={{
          background: `rgba(${hexToRgb(sampRating.color)},0.06)`,
          border: `1px solid rgba(${hexToRgb(sampRating.color)},0.25)`,
          borderRadius: 12, padding: "18px 16px", textAlign: "center",
        }}>
          <div style={{ fontSize: 10, letterSpacing: "0.2em", color: "rgba(180,200,230,0.45)", marginBottom: 8 }}>CAMPIONAMENTO</div>
          <div style={{ fontSize: "2.6rem", fontWeight: 700, color: sampRating.color, lineHeight: 1, textShadow: `0 0 20px ${sampRating.color}` }}>
            {sampling.toFixed(3)}<span style={{ fontSize: "1.1rem" }}>"</span>
          </div>
          <div style={{ marginTop: 6, fontSize: 11, color: sampRating.color, letterSpacing: "0.05em" }}>{sampRating.label}</div>
          <div style={{ marginTop: 4, fontSize: 10, color: "rgba(180,200,230,0.35)" }}>Ideale: {min}" – {max}"/px</div>
          <div style={{ marginTop: 10 }}>
            <GaugeArc value={sampling} min={0} max={Math.max(4, max * 2.2)} color={sampRating.color} label={`${sampling.toFixed(2)}"`} />
          </div>
        </div>

        {/* Rapporto focale */}
        <div style={{
          background: fRatio > 0 ? `rgba(${hexToRgb(frRating.color)},0.06)` : "rgba(255,255,255,0.03)",
          border: fRatio > 0 ? `1px solid rgba(${hexToRgb(frRating.color)},0.25)` : "1px solid rgba(255,255,255,0.06)",
          borderRadius: 12, padding: "18px 16px", textAlign: "center",
        }}>
          <div style={{ fontSize: 10, letterSpacing: "0.2em", color: "rgba(180,200,230,0.45)", marginBottom: 8 }}>RAPPORTO FOCALE</div>
          {fRatio > 0 ? (
            <>
              <div style={{ fontSize: "2.6rem", fontWeight: 700, color: frRating.color, lineHeight: 1, textShadow: `0 0 20px ${frRating.color}` }}>
                f/<span>{fRatio.toFixed(1)}</span>
              </div>
              <div style={{ marginTop: 6, fontSize: 11, color: frRating.color, letterSpacing: "0.05em" }}>{frRating.label}</div>
              <div style={{ marginTop: 4, fontSize: 10, color: "rgba(180,200,230,0.35)" }}>Ideale: f/{frMin} – f/{frMax}</div>
              <div style={{ marginTop: 10 }}>
                <GaugeArc value={fRatio} min={0} max={60} color={frRating.color} label={`f/${fRatio.toFixed(1)}`} />
              </div>
            </>
          ) : (
            <div style={{ color: "rgba(180,200,230,0.3)", fontSize: 12, marginTop: 20 }}>Inserisci apertura<br/>per calcolare f/</div>
          )}
        </div>
      </div>

      {/* ── Barra visiva rapporto focale ── */}
      {fRatio > 0 && (
        <div style={{
          background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
          borderRadius: 10, padding: "16px 18px", marginBottom: 20,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 10, letterSpacing: "0.2em", color: "rgba(180,200,230,0.45)" }}>📊 SCALA RAPPORTO FOCALE</div>
            <div style={{ fontSize: 10, color: "rgba(129,199,132,0.7)", letterSpacing: "0.05em" }}>■ zona ideale f/{frMin}–f/{frMax}</div>
          </div>
          <FocalRatioBar fRatio={fRatio} idealMin={frMin} idealMax={frMax} />
        </div>
      )}

      {/* ── Grid dati ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10, marginBottom: 20 }}>
        <DataChip icon="🔭" label="Telescopio" value={telescope.name}
          sub={barlow.factor > 1 || filter.focalMultiplier > 1
            ? `base ${baseFocalLength}mm → eff. ${focalLength.toFixed(0)}mm · f/${fRatio.toFixed(1)}`
            : `focale ${focalLength.toFixed(0)}mm · f/${fRatio > 0 ? fRatio.toFixed(1) : "—"}`}
          color="#4fc3f7" />
        <DataChip icon="📷" label="Camera" value={camera.name} sub={`pixel eff. ${effectivePixel.toFixed(2)} µm${binning > 1 ? ` · bin ${binning}×${binning}` : ""}`} color="#b39ddb" />
        {barlow.factor > 1 && (
          <DataChip icon="🔬" label="Barlow" value={barlow.name} sub={`×${barlow.factor} – focale ×${barlow.factor}`} color="#a5d6a7" />
        )}
        {filter.id !== "none" && (
          <DataChip icon="🌞" label="Filtro" value={filter.name} sub={`×${filter.focalMultiplier} eq. focale · ${filter.wavelength || ""}`} color="#ff6e40" />
        )}
      </div>

      {/* ── Consigli ── */}
      <div style={{
        background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: "16px 20px",
        borderLeft: `3px solid ${objectType.color}`,
      }}>
        <div style={{ fontSize: 10, letterSpacing: "0.2em", color: "rgba(180,200,230,0.45)", marginBottom: 8 }}>💡 CONSIGLI TECNICI</div>
        <p style={{ margin: 0, fontSize: 12, lineHeight: 1.7, color: "rgba(200,220,240,0.75)" }}>{objectType.notes}</p>

        {sampDiff !== "dentro" && (
          <p style={{ margin: "10px 0 0", fontSize: 12, color: "rgba(255,200,100,0.8)", lineHeight: 1.6 }}>
            {sampDiff === "sotto"
              ? `⚠️ Campionamento ${sampling.toFixed(2)}" troppo fine. Considera un riduttore focale o binning superiore.`
              : `⚠️ Campionamento ${sampling.toFixed(2)}" troppo grossolano. Considera una barlow o una camera con pixel più piccoli.`}
          </p>
        )}

        {frAdvice && (
          <p style={{ margin: "10px 0 0", fontSize: 12, color: frRating.status === "ok" ? "rgba(129,199,132,0.8)" : "rgba(255,200,100,0.8)", lineHeight: 1.6 }}>
            {frAdvice}
          </p>
        )}
      </div>

      {/* ── CONFRONTO CAMERA CONSIGLIATA vs SCELTA ── */}
      {showComparison && cmpMsg && (
        <div style={{
          marginTop: 20,
          borderRadius: 12,
          border: `1px solid rgba(${hexToRgb(cmpMsg.color)},0.4)`,
          background: `rgba(${hexToRgb(cmpMsg.color)},0.06)`,
          overflow: "hidden",
          animation: "fadeIn 0.3s ease",
        }}>
          {/* header */}
          <div style={{
            padding: "10px 18px",
            background: `rgba(${hexToRgb(cmpMsg.color)},0.12)`,
            borderBottom: `1px solid rgba(${hexToRgb(cmpMsg.color)},0.2)`,
            fontSize: 10, fontWeight: 700, letterSpacing: "0.2em", color: cmpMsg.color,
            textTransform: "uppercase",
          }}>
            {cmpMsg.icon} Confronto: Camera Scelta vs Consigliata
          </div>
          {/* barra comparativa */}
          <div style={{ padding: "16px 18px" }}>
            {/* riga camera consigliata */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                <div style={{ fontSize: 11, color: "#81c784", fontWeight: 700 }}>🥇 {topRec.name} <span style={{ fontSize: 9, color: "rgba(129,199,132,0.6)", fontWeight: 400 }}>(consigliata)</span></div>
                <div style={{ fontSize: 12, fontWeight: 700, color: recRating.color }}>{recSampling.toFixed(3)}" <span style={{ fontSize: 9 }}>{recRating.label}</span></div>
              </div>
              <SamplingBar sampling={recSampling} min={objectType.idealSampling.min} max={objectType.idealSampling.max} color={recRating.color} />
            </div>
            {/* riga camera scelta */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                <div style={{ fontSize: 11, color: "#b39ddb", fontWeight: 700 }}>📷 {camera.name} <span style={{ fontSize: 9, color: "rgba(179,157,219,0.6)", fontWeight: 400 }}>(tua scelta)</span></div>
                <div style={{ fontSize: 12, fontWeight: 700, color: sampRating.color }}>{sampling.toFixed(3)}" <span style={{ fontSize: 9 }}>{sampRating.label}</span></div>
              </div>
              <SamplingBar sampling={sampling} min={objectType.idealSampling.min} max={objectType.idealSampling.max} color={sampRating.color} />
            </div>
            {/* messaggio */}
            <div style={{
              fontSize: 11, lineHeight: 1.7, color: cmpMsg.color,
              padding: "10px 14px", borderRadius: 8,
              background: `rgba(${hexToRgb(cmpMsg.color)},0.08)`,
              borderLeft: `3px solid ${cmpMsg.color}`,
            }}>
              {cmpMsg.text}
            </div>
            {/* differenza pixel */}
            <div style={{ marginTop: 10, display: "flex", gap: 10, flexWrap: "wrap" }}>
              <div style={{ fontSize: 10, color: "rgba(180,200,230,0.4)" }}>
                Δ campionamento: <strong style={{ color: cmpMsg.color }}>{sampDiffPct > 0 ? "+" : ""}{sampDiffPct.toFixed(1)}%</strong>
              </div>
              <div style={{ fontSize: 10, color: "rgba(180,200,230,0.4)" }}>
                Pixel tua camera: <strong style={{ color: "#b39ddb" }}>{camera.pixelSize}µm</strong> · Pixel consigliata: <strong style={{ color: "#81c784" }}>{topRec.pixelSize}µm</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Se stai usando la camera consigliata ── */}
      {topRec && isUsingRec && (
        <div style={{
          marginTop: 20, padding: "12px 18px", borderRadius: 10,
          border: "1px solid rgba(129,199,132,0.35)",
          background: "rgba(129,199,132,0.06)",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <span style={{ fontSize: 18 }}>✅</span>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#81c784", marginBottom: 2 }}>Stai usando la camera ideale per questo setup</div>
            <div style={{ fontSize: 10, color: "rgba(129,199,132,0.6)" }}>{camera.name} è la prima scelta consigliata per {objectType.icon} {objectType.label} con {telescope.name}.</div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── UI ATOMS ─────────────────────────────────────────────────────────────────

function Tag({ color, children }) {
  return (
    <span style={{
      fontSize: 10, padding: "2px 8px", borderRadius: 4,
      border: `1px solid ${color}`, color, letterSpacing: "0.06em",
      background: `rgba(${hexToRgb(color)},0.08)`,
    }}>{children}</span>
  );
}

function Card({ title, accent, children }) {
  return (
    <div style={{
      background: "linear-gradient(160deg, rgba(10,20,36,0.95) 0%, rgba(4,8,16,0.98) 100%)",
      border: `1px solid rgba(${hexToRgb(accent)},0.2)`,
      borderRadius: 14, padding: "22px 20px",
      boxShadow: `0 4px 24px rgba(0,0,0,0.4), 0 0 0 0 ${accent}`,
    }}>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.2em", color: accent, marginBottom: 16, textTransform: "uppercase" }}>{title}</div>
      {children}
    </div>
  );
}

function TabToggle({ value, onChange, options, accent }) {
  return (
    <div style={{ display: "flex", background: "rgba(255,255,255,0.04)", borderRadius: 7, padding: 3, marginBottom: 14, gap: 2 }}>
      {options.map(o => (
        <button key={o.value} onClick={() => onChange(o.value)} style={{
          flex: 1, padding: "6px 8px", borderRadius: 5, border: "none", cursor: "pointer",
          background: value === o.value ? `rgba(${hexToRgb(accent)},0.2)` : "transparent",
          color: value === o.value ? accent : "rgba(180,200,230,0.45)",
          fontSize: 11, fontFamily: "inherit", fontWeight: 700, letterSpacing: "0.08em",
          transition: "all 0.15s", boxShadow: value === o.value ? `0 0 8px rgba(${hexToRgb(accent)},0.25)` : "none",
        }}>{o.label}</button>
      ))}
    </div>
  );
}

function Select({ value, onChange, children, accent }) {
  return (
    <select value={value} onChange={e => onChange(e.target.value)} style={{
      width: "100%", padding: "9px 12px", borderRadius: 8, marginBottom: 10,
      background: "rgba(255,255,255,0.05)", border: `1px solid rgba(${hexToRgb(accent)},0.25)`,
      color: "#c8d8f0", fontSize: 12, fontFamily: "inherit", cursor: "pointer", outline: "none",
      appearance: "none",
      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%234fc3f7'/%3E%3C/svg%3E")`,
      backgroundRepeat: "no-repeat", backgroundPosition: "right 10px center",
    }}>{children}</select>
  );
}

function Input({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 10, color: "rgba(180,200,230,0.45)", letterSpacing: "0.12em", marginBottom: 4 }}>{label.toUpperCase()}</div>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{
          width: "100%", padding: "8px 12px", borderRadius: 7, border: "1px solid rgba(255,255,255,0.1)",
          background: "rgba(255,255,255,0.05)", color: "#e0f0ff", fontSize: 12, fontFamily: "inherit", outline: "none",
        }}
      />
    </div>
  );
}

function InfoRow({ label, value, color }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
      <span style={{ fontSize: 11, color: "rgba(180,200,230,0.45)" }}>{label}</span>
      <span style={{ fontSize: 12, fontWeight: 700, color: color || "#c8d8f0" }}>{value}</span>
    </div>
  );
}

function DataChip({ icon, label, value, sub, color }) {
  return (
    <div style={{
      background: `rgba(${hexToRgb(color)},0.06)`, border: `1px solid rgba(${hexToRgb(color)},0.18)`,
      borderRadius: 10, padding: "12px 14px",
    }}>
      <div style={{ fontSize: 10, color: "rgba(180,200,230,0.4)", letterSpacing: "0.15em", marginBottom: 4 }}>{icon} {label.toUpperCase()}</div>
      <div style={{ fontSize: 12, fontWeight: 700, color, marginBottom: 2 }}>{value}</div>
      <div style={{ fontSize: 11, color: "rgba(180,200,230,0.4)" }}>{sub}</div>
    </div>
  );
}

function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? `${parseInt(r[1], 16)},${parseInt(r[2], 16)},${parseInt(r[3], 16)}` : "128,128,128";
}
